
  # RescueRoute AI Dashboard Design (Copy)

  This is a code bundle for RescueRoute AI Dashboard Design (Copy). The original project is available at https://www.figma.com/design/Rtgosp0weahfapFD54QQ8K/RescueRoute-AI-Dashboard-Design--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  